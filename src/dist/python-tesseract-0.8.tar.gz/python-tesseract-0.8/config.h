#pragma once
#ifndef __linux__
	#define __linux__
#endif
#ifndef __opencv2__
	#define __opencv2__
#endif
#include <opencv2/core/core_c.h>
#ifndef __opencv__
	#define __opencv__
#endif
#include <cv.h>
#include <Python.h>
