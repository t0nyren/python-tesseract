#pragma once
#define __windows__

#define __opencv2__

#include "opencv2/core/core_c.h"
#include <Python.h>
#include "util-fmemopen.h"
